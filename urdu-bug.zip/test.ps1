# simulate_tv_signals.ps1

$webhookUrl = "http://localhost:5000/tv_urdu"

# Signal 1 : achat sur GC
$body1 = "instrument:UB1!,position:0"

# Signal 2 : vente sur UB1!
$body2 = "instrument:UB1!,position:-1"

# Envoyer les deux signaux avec un petit délai
Invoke-RestMethod -Uri $webhookUrl -Method POST -Body $body1 -ContentType "text/plain"
Start-Sleep -Milliseconds 500
Invoke-RestMethod -Uri $webhookUrl -Method POST -Body $body2 -ContentType "text/plain"

Write-Host "✅ Deux signaux envoyés au webhook"
