from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, Optional, Tuple

import requests

log = logging.getLogger("urdu_exec_bot.api")


def _mask(s: Optional[str], keep: int = 3) -> str:
    if not s:
        return ""
    if len(s) <= keep:
        return "*" * len(s)
    return "*" * (len(s) - keep) + s[-keep:]


class TopstepXHttp:
    """
    Couche HTTP bas niveau: gère base_url, session, headers, auth-style.
    - auth_style: 'both' | 'xapikey' | 'bearer'
    - loginKey: envoie x-api-key et (optionnellement) Authorization=api_key (comme dans tes logs)
    - après login: met Authorization = token (⚠️ sans 'Bearer ' d’après tes traces)
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        username: str,
        account_id: str,
        auth_style: str = "both",
        timeout: float = 15.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or ""
        self.username = username or ""
        self.account_id = str(account_id or "")
        self.auth_style = (auth_style or "both").lower()
        self.timeout = timeout
        self.session = requests.Session()
        self.token: Optional[str] = None

    # ─────────────────────────── Headers ───────────────────────────
    def _common_headers(self) -> Dict[str, str]:
        h = {
            "Content-Type": "application/json",
            "x-username": self.username,
            "x-account-id": self.account_id,
        }
        # x-api-key si demandé par la conf
        if self.auth_style in ("xapikey", "both"):
            if self.api_key:
                h["x-api-key"] = self.api_key
        # Authorization
        if self.token and self.auth_style in ("bearer", "both"):
            # ⚠️ les logs montrent le token brut (pas de "Bearer ")
            h["Authorization"] = self.token
        return h

    def _login_headers(self) -> Dict[str, str]:
        # Pour loginKey, on réplique ce que tu faisais :
        # - x-api-key
        # - Authorization = api_key (dans tes logs avant d'avoir un token)
        h = {
            "Content-Type": "application/json",
            "x-username": self.username,
            "x-account-id": self.account_id,
        }
        if self.api_key:
            h["x-api-key"] = self.api_key
            h["Authorization"] = self.api_key
        return h

    def _url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}/{path.lstrip('/')}"

    # ─────────────────────────── Low-level requests ───────────────────────────
    def post(self, path: str, json_body: Dict[str, Any], *, use_login_headers=False) -> Tuple[int, Any]:
        url = self._url(path)
        headers = self._login_headers() if use_login_headers else self._common_headers()

        # logs DEBUG “HTTP OUT”
        try:
            body_str = json.dumps(json_body, ensure_ascii=False)
        except Exception:
            body_str = str(json_body)
        safe_headers = {
            k: (v if k not in {"x-api-key", "Authorization"} else _mask(v))
            for k, v in headers.items()
        }
        log.info("[HTTP OUT] POST %s", url)
        log.info("[HTTP OUT] headers=%s", safe_headers)
        log.info("[HTTP OUT] body=%s", body_str)
        log.info("[HTTP OUT] curl=curl -X POST %r %s -d %r",
                 url,
                 " ".join([f"-H {json.dumps(f'{k}: {v}')}" for k, v in safe_headers.items()]),
                 body_str)

        resp = self.session.post(url, headers=headers, json=json_body, timeout=self.timeout)
        return self._handle_response(resp)

    def get(self, path: str) -> Tuple[int, Any]:
        url = self._url(path)
        headers = self._common_headers()
        safe_headers = {
            k: (v if k not in {"x-api-key", "Authorization"} else _mask(v))
            for k, v in headers.items()
        }
        log.info("[HTTP OUT] GET %s", url)
        log.info("[HTTP OUT] headers=%s", safe_headers)
        log.info("[HTTP OUT] curl=curl -X GET %r %s",
                 url, " ".join([f"-H {json.dumps(f'{k}: {v}')}" for k, v in safe_headers.items()]))

        resp = self.session.get(url, headers=headers, timeout=self.timeout)
        return self._handle_response(resp)

    def _handle_response(self, resp: requests.Response) -> Tuple[int, Any]:
        status = resp.status_code
        try:
            data = resp.json() if resp.content else None
        except Exception:
            data = resp.text
        log.info("[HTTP IN ] status=%s", status)
        if data is not None:
            # évite d’inonder les logs si énorme
            dump = data
            try:
                dump_str = json.dumps(dump, ensure_ascii=False)
            except Exception:
                dump_str = str(dump)
            log.info("[HTTP IN ] body=%s", dump_str[:2000])
        return status, data
