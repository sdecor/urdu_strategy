from __future__ import annotations

import logging
from typing import Optional, Tuple

from .http import TopstepXHttp

log = logging.getLogger("urdu_exec_bot")


class TopstepXAuth:
    LOGIN_PATH = "/api/Auth/loginKey"

    @staticmethod
    def login_key(http: TopstepXHttp) -> Tuple[bool, Optional[str]]:
        """
        POST /api/Auth/loginKey
        body: {"apiKey": "<API_KEY>", "userName": "<username>"}
        Retourne (ok, token_str)
        """
        payload = {"apiKey": http.api_key, "userName": http.username}
        status, data = http.post(TopstepXAuth.LOGIN_PATH, payload, use_login_headers=True)
        if status == 200 and isinstance(data, dict) and data.get("success") and data.get("token"):
            token = str(data["token"])
            log.info("[TopstepX] auth OK")
            return True, token
        log.error("[TopstepX] auth FAIL status=%s data=%s", status, data)
        return False, None
