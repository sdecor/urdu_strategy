# src/urdu_exec_bot/__init__.py
# Garder ce fichier ultra-léger pour éviter les import-time errors.
__all__ = []
