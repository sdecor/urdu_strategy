from __future__ import annotations

import logging
from typing import Dict, Any, Optional, Union

from urdu_exec_bot.state.models import TradeState, PositionSnapshot
from urdu_exec_bot.state.repository_file import FileStateRepository
from urdu_exec_bot.services.topstepx_client import TSSide

log = logging.getLogger("urdu_exec_bot.state.store")


class StateStore:
    """
    API in-memory (compat avec l'ancien StateStore) + persistance déléguée au repo.
    Méthodes attendues par app.py:
      - load()
      - save()
      - get_offset() / set_offset()
      - get_position() / set_position_abs()
      - apply_fill()
      - snapshot()
    """

    def __init__(self, repo: Optional[FileStateRepository] = None) -> None:
        print("✔ StateStore loaded from:", inspect.getfile(self.__class__))
        self.repo = repo or FileStateRepository()
        self.state: TradeState = TradeState()

    # ----------------------- lifecycle -----------------------
    def load(self) -> Dict[str, Any]:
        self.state = self.repo.load()
        return self.snapshot()

    def save(self) -> None:
        self.repo.save(self.state)

    # ----------------------- offsets -----------------------
    def get_offset(self, name: str = "csv") -> int:
        try:
            return int(self.state.offsets.get(name, 0))
        except Exception:
            return 0

    def set_offset(self, name: str, value: int) -> None:
        self.state.offsets[name] = int(value)
        # écrire immédiatement (comme avant) pour minimiser la perte en cas d’arrêt
        self.save()

    # ----------------------- positions -----------------------
    def get_position(self, instrument: str) -> int:
        snap = self.state.positions.get(instrument.upper())
        return int(snap.net) if snap else 0

    def set_position_abs(self, instrument: str, contract_id: str, value: Union[int, str]) -> None:
        try:
            v = int(value)
        except Exception:
            v = 0
        inst = instrument.upper()
        self.state.positions[inst] = PositionSnapshot(contract_id=str(contract_id), net=v)
        self.save()

    def apply_fill(
        self,
        instrument: str,
        contract_id: str,
        side: Union[TSSide, str, int],
        qty: Union[int, str],
    ) -> int:
        try:
            q = abs(int(qty))
        except Exception:
            q = 0

        # normalise le côté
        if isinstance(side, TSSide):
            side_name = "BUY" if side == TSSide.BUY else "SELL"
        elif isinstance(side, int):
            # convention interne client: 0=BUY, 1=SELL
            side_name = "BUY" if side == 0 else "SELL"
        else:
            side_name = str(side).upper()

        inst = instrument.upper()
        cur = self.get_position(inst)

        if side_name == "BUY":
            new_v = cur + q
        elif side_name == "SELL":
            new_v = cur - q
        else:
            log.warning("apply_fill: côté inconnu (%s), aucune modif de position", side)
            new_v = cur

        self.state.positions[inst] = PositionSnapshot(contract_id=str(contract_id), net=int(new_v))
        self.save()
        return int(new_v)

    # ----------------------- debug -----------------------
    def snapshot(self) -> Dict[str, Any]:
        return {
            "positions": {
                k: {
                    "contract_id": v.contract_id,
                    "net": int(v.net),
                    "updated_at": v.updated_at,
                }
                for k, v in self.state.positions.items()
            },
            "offsets": {k: int(v) for k, v in (self.state.offsets or {}).items()},
            "updated_at": self.state.updated_at,
        }
