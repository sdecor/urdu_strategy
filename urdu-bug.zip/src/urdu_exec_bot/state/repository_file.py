from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any

from urdu_exec_bot.state.models import TradeState, PositionSnapshot
from urdu_exec_bot.utils.settings_loader import load_settings, resolve_path

log = logging.getLogger("urdu_exec_bot.state.repo")


def _ensure_parent(p: Path) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)


def _atomic_write_text(p: Path, data: str, encoding: str = "utf-8") -> None:
    _ensure_parent(p)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(data, encoding=encoding)
    tmp.replace(p)


class FileStateRepository:
    """
    Persistance fichier:
      - trade_state.json: positions + updated_at (+ offsets si on veut tout-in-one)
      - offset file      : compat 'plain int' pour l'offset CSV (ou JSON si plusieurs offsets)
    """

    def __init__(
        self,
        trade_state_path: Optional[Path | str] = None,
        offset_path: Optional[Path | str] = None,
    ) -> None:
        settings = load_settings() or {}
        state_paths = (settings.get("paths") or {}).get("state") or {}

        self.trade_state_path: Path = resolve_path(
            trade_state_path or state_paths.get("trade_state") or "state/trade_state.json"
        )
        self.offset_path: Path = resolve_path(
            offset_path or state_paths.get("offset") or "state/offsets/signals.offset"
        )

    # ----------------------- LOAD -----------------------
    def load(self) -> TradeState:
        state = TradeState()

        # 1) trade_state.json
        try:
            if self.trade_state_path.exists():
                raw = self.trade_state_path.read_text(encoding="utf-8")
                if raw.strip():
                    loaded = json.loads(raw)
                    state = TradeState.from_dict(loaded)
        except Exception as e:
            log.warning("Lecture trade_state échouée (%s): %s", self.trade_state_path, e)

        # 2) offset (compat: entier simple) -> offsets['csv']
        try:
            if self.offset_path.exists():
                raw = self.offset_path.read_text(encoding="utf-8").strip()
                if raw:
                    # compat entier simple
                    try:
                        off = int(raw)
                        state.offsets["csv"] = off
                    except ValueError:
                        # fallback JSON
                        data = json.loads(raw)
                        if isinstance(data, dict):
                            for k, v in data.items():
                                try:
                                    state.offsets[str(k)] = int(v)
                                except Exception:
                                    pass
        except Exception as e:
            log.warning("Lecture offset échouée (%s): %s", self.offset_path, e)

        return state

    # ----------------------- SAVE -----------------------
    def save(self, state: TradeState) -> None:
        # A) trade_state.json
        try:
            payload = json.dumps(
                {
                    "positions": {k: v.to_dict() for k, v in state.positions.items()},
                    "updated_at": state.updated_at,
                },
                ensure_ascii=False,
                indent=2,
            )
            _atomic_write_text(self.trade_state_path, payload)
        except Exception as e:
            log.error("Écriture trade_state échouée: %s", e)

        # B) offset: si un seul offset 'csv' => écrire entier simple (compat),
        #            sinon écrire JSON
        try:
            offsets = state.offsets or {}
            if set(offsets.keys()) == {"csv"}:
                _atomic_write_text(self.offset_path, f"{int(offsets.get('csv', 0))}\n")
            else:
                payload = json.dumps({k: int(v) for k, v in offsets.items()}, ensure_ascii=False, indent=2)
                _atomic_write_text(self.offset_path, payload)
        except Exception as e:
            log.error("Écriture offset échouée: %s", e)
