from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, Any


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class PositionSnapshot:
    contract_id: str
    net: int = 0
    updated_at: str = field(default_factory=_iso_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "contract_id": self.contract_id,
            "net": int(self.net),
            "updated_at": self.updated_at,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "PositionSnapshot":
        return PositionSnapshot(
            contract_id=str(d.get("contract_id", "")),
            net=int(d.get("net", 0)),
            updated_at=str(d.get("updated_at") or _iso_now()),
        )


@dataclass
class TradeState:
    positions: Dict[str, PositionSnapshot] = field(default_factory=dict)  # instrument -> snapshot
    offsets: Dict[str, int] = field(default_factory=dict)                 # name -> offset
    updated_at: str = field(default_factory=_iso_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "positions": {k: v.to_dict() for k, v in self.positions.items()},
            "offsets": {k: int(v) for k, v in self.offsets.items()},
            "updated_at": self.updated_at,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "TradeState":
        raw_pos = d.get("positions") or {}
        positions = {
            str(k).upper(): PositionSnapshot.from_dict(v) for k, v in raw_pos.items()
            if isinstance(v, dict)
        }
        raw_off = d.get("offsets") or {}
        offsets = {str(k): int(v) for k, v in raw_off.items() if v is not None}
        return TradeState(
            positions=positions,
            offsets=offsets,
            updated_at=str(d.get("updated_at") or _iso_now()),
        )
