from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml


def _guess_project_root() -> Path:
    """
    Retourne la racine du projet.
    Corrige le bug: on doit remonter 3 niveaux depuis ce fichier pour sortir de 'src/'.
      .../src/urdu_exec_bot/utils/settings_loader.py
        parents[0] = .../src/urdu_exec_bot/utils
        parents[1] = .../src/urdu_exec_bot
        parents[2] = .../src
        parents[3] = .../   ✓ racine projet
    """
    here = Path(__file__).resolve()
    pr = here.parents[3]
    return pr


def resolve_path(p: str | os.PathLike) -> Path:
    """
    Résout un chemin relatif par rapport à la racine du projet.
    Laisse inchangé s'il est déjà absolu.
    """
    pth = Path(p)
    if pth.is_absolute():
        return pth
    return (_guess_project_root() / pth).resolve()


def load_settings() -> Dict[str, Any]:
    """
    Charge le YAML de configuration en respectant:
      - SETTINGS_PATH (absolu ou relatif à la racine du projet)
      - sinon défaut: <root>/config/settings.yaml
    """
    env_path = os.environ.get("SETTINGS_PATH")
    cfg_path = resolve_path(env_path) if env_path else (_guess_project_root() / "config" / "settings.yaml")

    cfg_path = Path(cfg_path)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Settings file not found at: {cfg_path}")

    with cfg_path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data
