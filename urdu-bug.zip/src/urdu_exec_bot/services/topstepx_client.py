from __future__ import annotations

from urdu_exec_bot.adapters.topstepx import TopstepXClient, TSOrderType, TSSide

__all__ = ["TopstepXClient", "TSOrderType", "TSSide"]

import json
import logging
import os
from typing import Any, Dict, Optional, Tuple

import requests


class TSOrderType:
    LIMIT = 1
    MARKET = 2
    STOP = 4
    TRAILING_STOP = 5
    JOIN_BID = 6
    JOIN_ASK = 7


class TSSide:
    BUY = 0   # Bid
    SELL = 1  # Ask


def _ok_json(resp: requests.Response) -> Tuple[bool, Dict[str, Any]]:
    try:
        resp.raise_for_status()
        data = resp.json() if resp.text else {}
        return True, data
    except Exception as e:
        try:
            body = resp.json()
        except Exception:
            body = {"text": resp.text}
        return False, {"error": str(e), "status": resp.status_code, "body": body}


def _mask_headers(headers: Dict[str, Any]) -> Dict[str, Any]:
    masked = dict(headers or {})
    if "Authorization" in masked:
        masked["Authorization"] = "Bearer ***"
    if "authorization" in masked:
        masked["authorization"] = "Bearer ***"
    return masked


class TopstepXClient:
    """
    .env requis:
      TOPSTEPX_BASE_URL
      TOPSTEPX_USERNAME
      TOPSTEPX_ACCOUNT_ID
      TOPSTEPX_API_KEY

    Auth: POST /api/Auth/loginKey { userName, apiKey } -> token, à réutiliser en Bearer.
    """

    def __init__(self, timeout: int = 15) -> None:
        self.log = logging.getLogger("urdu_exec_bot.api")

        self.base_url = (os.getenv("TOPSTEPX_BASE_URL", "") or "").rstrip("/")
        self.username = os.getenv("TOPSTEPX_USERNAME", "") or ""
        self.account_id = os.getenv("TOPSTEPX_ACCOUNT_ID", "") or ""
        self.api_key = os.getenv("TOPSTEPX_API_KEY", "") or ""
        self.timeout = int(timeout)

        missing = [k for k, v in [
            ("TOPSTEPX_BASE_URL", self.base_url),
            ("TOPSTEPX_USERNAME", self.username),
            ("TOPSTEPX_ACCOUNT_ID", self.account_id),
            ("TOPSTEPX_API_KEY", self.api_key),
        ] if not v]
        if missing:
            self.log.error("[TopstepX] Variables .env manquantes: %s", ", ".join(missing))

        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        self._jwt: Optional[str] = None

        ok, data = self._login_with_key()
        if not ok:
            self.log.error("[TopstepX] Échec loginKey: %s", data)
        else:
            self.log.debug("[TopstepX] loginKey OK (token reçu)")

    # ---------------- internals ----------------

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _set_bearer(self, token: str) -> None:
        self.session.headers["Authorization"] = f"Bearer {token}"

    def _login_with_key(self) -> Tuple[bool, Dict[str, Any]]:
        url = self._url("/api/Auth/loginKey")
        payload = {"userName": self.username, "apiKey": self.api_key}

        self.log.debug("API CALL: POST %s payload=%s headers=%s",
                       url, json.dumps(payload, ensure_ascii=False),
                       _mask_headers(self.session.headers))

        resp = self.session.post(url, json=payload, timeout=self.timeout)

        self.log.debug("API RESP: %s %s", resp.status_code, resp.text)

        ok, data = _ok_json(resp)
        if ok:
            token = data.get("token") or data.get("Token") or data.get("data", {}).get("token")
            if not token:
                return False, {"error": "loginKey OK mais token absent", "body": data}
            self._jwt = token
            self._set_bearer(token)
        return ok, data

    def _authed_post(self, path: str, json_body: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        url = self._url(path)

        self.log.debug("API CALL: POST %s payload=%s headers=%s",
                       url, json.dumps(json_body, ensure_ascii=False),
                       _mask_headers(self.session.headers))

        resp = self.session.post(url, json=json_body, timeout=self.timeout)

        self.log.debug("API RESP: %s %s", resp.status_code, resp.text)

        ok, data = _ok_json(resp)
        if ok or data.get("status") != 401:
            return ok, data

        # 401 → relogin + retry
        self.log.warning("[TopstepX] 401 détecté, tentative de relogin et retry…")
        ok_login, _ = self._login_with_key()
        if not ok_login:
            return False, {"error": "relogin failed after 401", "orig": data}

        self.log.debug("API RETRY: POST %s payload=%s headers=%s",
                       url, json.dumps(json_body, ensure_ascii=False),
                       _mask_headers(self.session.headers))

        resp2 = self.session.post(url, json=json_body, timeout=self.timeout)
        self.log.debug("API RESP RETRY: %s %s", resp2.status_code, resp2.text)
        return _ok_json(resp2)

    # -------------- sanity/auth --------------

    def validate_auth(self) -> Tuple[bool, Dict[str, Any]]:
        if not self._jwt:
            ok, data = self._login_with_key()
            if not ok:
                return ok, data
        return self._authed_post("/api/Account/search", {"request": {}})

    # -------------- reference data ----------

    def contracts_available(self, *, live: bool = False, limit: Optional[int] = None) -> Tuple[bool, Dict[str, Any]]:
        body: Dict[str, Any] = {"request": {"live": bool(live)}}
        if limit is not None:
            body["request"]["limit"] = int(limit)
        return self._authed_post("/api/Contract/available", body)

    # -------------- accounts/positions/orders ---------

    def accounts(self) -> Tuple[bool, Dict[str, Any]]:
        return self._authed_post("/api/Account/search", {"request": {}})

    def position_search_open(self, account_id: Optional[str] = None) -> Tuple[bool, Dict[str, Any]]:
        """
        Certains environnements attendent {"accountId": 10832315} à la racine,
        d'autres attendent {"request":{"accountId": 10832315}}.
        On tente les deux, avec logs détaillés.
        """
        aid = int(account_id or self.account_id)

        # tentative 1: root payload
        body1 = {"accountId": aid}
        self.log.debug("API CALL: POST %s payload=%s headers=%s",
                       self._url("/api/Position/searchOpen"),
                       json.dumps(body1, ensure_ascii=False),
                       _mask_headers(self.session.headers))
        r1 = self.session.post(self._url("/api/Position/searchOpen"), json=body1, timeout=self.timeout)
        self.log.debug("API RESP: %s %s", r1.status_code, r1.text)
        ok1, data1 = _ok_json(r1)
        if ok1:
            return ok1, data1

        # tentative 2: nested request payload
        body2 = {"request": {"accountId": aid}}
        self.log.debug("API CALL (fallback): POST %s payload=%s headers=%s",
                       self._url("/api/Position/searchOpen"),
                       json.dumps(body2, ensure_ascii=False),
                       _mask_headers(self.session.headers))
        r2 = self.session.post(self._url("/api/Position/searchOpen"), json=body2, timeout=self.timeout)
        self.log.debug("API RESP (fallback): %s %s", r2.status_code, r2.text)
        return _ok_json(r2)

    def order_search_open(self, account_id: Optional[str] = None) -> Tuple[bool, Dict[str, Any]]:
        aid = int(account_id or self.account_id)
        return self._authed_post("/api/Order/searchOpen", {"request": {"accountId": aid}})

    # -------------- order place -----------------------

    def place_order(
        self,
        *,
        contract_id: str,
        side: int,
        order_type: int,
        qty: int,
        price: Optional[float] = None,
        custom_tag: Optional[str] = None,
        tif: Optional[str] = None,  # ex: "DAY"
    ) -> Tuple[bool, Dict[str, Any]]:
        payload: Dict[str, Any] = {
            "accountId": int(self.account_id),
            "contractId": str(contract_id),
            "type": int(order_type),
            "side": int(side),
            "size": int(qty),
        }
        if price is not None:
            payload["price"] = float(price)
        if custom_tag:
            payload["customTag"] = str(custom_tag)
        if tif:
            payload["tif"] = str(tif)

        ok, data = self._authed_post("/api/Order/place", payload)

        if ok:
            if data.get("success") is False:
                self.log.error("PLACE NOK (success=false): %s", data)
                return False, data
            if data.get("orderId") is None:
                self.log.error("PLACE NOK (orderId manquant): %s", data)
                return False, data

        return ok, data
