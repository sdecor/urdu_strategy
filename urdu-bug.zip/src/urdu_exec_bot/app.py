from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from typing import List

from dotenv import load_dotenv

load_dotenv()

# ───────── LOGGING ─────────
LOG_FILE = "logs/urdu_exec_bot.log"
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_FILE, encoding="utf-8", mode="a"),
    ],
    force=True,
)
logging.getLogger("urllib3").setLevel(logging.DEBUG)
logging.getLogger("requests").setLevel(logging.DEBUG)
log = logging.getLogger("urdu_exec_bot")

# ───────── IMPORTS PROJET ─────────
from urdu_exec_bot.utils.settings_loader import load_settings, resolve_path
from urdu_exec_bot.io.ndjson_watcher import NdjsonWatcher
from urdu_exec_bot.parsers.signal_ndjson import SignalNdjsonParser
from urdu_exec_bot.services.state_store import StateStore
from urdu_exec_bot.services.topstepx_client import TopstepXClient
from urdu_exec_bot.app_support import _load_instruments_lots

from urdu_exec_bot.core.executor import Executor
from urdu_exec_bot.core.planner import _coalesce_by_second

POLL_INTERVAL_SEC = 0.5


def run() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug-auth", action="store_true")
    parser.add_argument("--debug-io", action="store_true")
    args, _ = parser.parse_known_args()

    settings = load_settings() or {}
    paths = settings.get("paths") or {}
    json_input = paths.get("ndjson_input") or "data/input/signals.ndjson"
    json_path = resolve_path(json_input)

    state_store = StateStore()
    _ = state_store.load()

    client = TopstepXClient()
    top_cfg = settings.get("topstepx") or {}
    contracts_map = {str(k).upper(): str(v) for k, v in (top_cfg.get("contracts") or {}).items()}
    lots_map = _load_instruments_lots(settings)
    account_id = os.getenv("TOPSTEPX_ACCOUNT_ID") or str(top_cfg.get("account_id", "")) or ""

    watcher = NdjsonWatcher(json_path=json_path, state_store=state_store)
    parser = SignalNdjsonParser(settings=settings)

    executor = Executor(
        client=client,
        state_store=state_store,
        account_id=account_id,
        contracts_map=contracts_map,
        lots_map=lots_map,
    )

    log.info("URDU Exec Bot démarré · account_id=%s · NDJSON=%s", account_id, json_path)
    log.debug("SETTINGS: %s", settings)
    log.debug("CONTRACTS MAP: %s", contracts_map)

    while True:
        try:
            entries = watcher.read_new_lines()
            if entries:
                if args.debug_io:
                    log.debug("RAW NDJSON (%d): %s", len(entries), entries)

                signals: List = []
                for entry in entries:
                    sig = parser.parse_entry(entry)
                    if sig and sig.target_pos is not None:
                        signals.append(sig)

                if not signals:
                    time.sleep(POLL_INTERVAL_SEC)
                    continue

                second_plan = _coalesce_by_second(signals)
                executor.process(second_plan)

        except Exception as e:
            log.exception("loop error: %s", e)

        time.sleep(POLL_INTERVAL_SEC)


def main() -> int:
    return run()


if __name__ == "__main__":
    sys.exit(main())
