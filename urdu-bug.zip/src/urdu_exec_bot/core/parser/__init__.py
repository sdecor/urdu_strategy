from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from ..models import Signal  # <- core/models.py
from .common import parse_csv_line as _parse_csv_line, parse_iso_utc, minute_key, second_key
from .formats import extract_from_kv, extract_from_fr

log = logging.getLogger("urdu_exec_bot")

class SignalParser:
    """
    Orchestrateur: transforme un enregistrement CSV -> Signal.
    Essaye successivement:
      1) format KV "instrument:...,position:..."
      2) fallback FR "La nouvelle position... sur ..."
    """

    @staticmethod
    def parse_csv_line(line: str) -> Optional[Dict[str, Any]]:
        return _parse_csv_line(line)

    @staticmethod
    def to_signal(rec: Dict[str, Any]) -> Optional[Signal]:
        raw = rec.get("raw", "") or ""

        instrument, target_pos = extract_from_kv(raw)
        action_hint: Optional[str] = None

        if instrument is None or target_pos is None:
            ins_fr, pos_fr, hint_fr = extract_from_fr(raw)
            instrument = instrument or ins_fr
            target_pos = target_pos if target_pos is not None else pos_fr
            action_hint = hint_fr

        if instrument is None or target_pos is None:
            return None

        ts = rec.get("received_at", "") or ""
        dt = parse_iso_utc(ts)

        sig = Signal(
            received_at=ts,
            minute_key=minute_key(dt),
            second_key=second_key(dt),
            instrument=instrument,
            target_pos=target_pos,
            raw_action_hint=action_hint,
        )
        log.debug("PARSE SIGNAL: %s", sig)
        return sig

# ---------- Wrappers pour compatibilité avec app.py ----------
def parse_csv_line(line: str) -> Optional[Dict[str, Any]]:
    """API attendue par app.py"""
    return SignalParser.parse_csv_line(line)

def to_signal(rec: Dict[str, Any]) -> Optional[Signal]:
    """API attendue par app.py"""
    return SignalParser.to_signal(rec)

__all__ = ["SignalParser", "parse_csv_line", "to_signal"]
