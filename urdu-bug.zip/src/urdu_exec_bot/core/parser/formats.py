from __future__ import annotations

from typing import Dict, Optional, Tuple

def extract_from_kv(raw: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Supporte: "instrument:UB1!,position:0"
    Retourne (instrument, target_pos).
    """
    if not raw:
        return (None, None)

    txt = raw.strip().strip('"').strip()
    parts = [p.strip() for p in txt.split(",")]
    kv: Dict[str, str] = {}
    for p in parts:
        if ":" not in p:
            continue
        k, v = p.split(":", 1)
        kv[k.strip().lower()] = v.strip()

    ins = kv.get("instrument")
    pos = kv.get("position")

    instrument = ins.upper() if ins else None
    target_pos: Optional[int] = None
    if pos is not None:
        try:
            pp = pos.replace("{", "").replace("}", "")
            target_pos = int(float(pp))
        except Exception:
            target_pos = None
    return (instrument, target_pos)

def extract_from_fr(raw: str) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    """
    Ancien format FR:
      "La nouvelle position de la stratégie est X sur UB1! … ordre buy/sell …"
    Retourne (instrument, target_pos, action_hint)
    """
    if not raw:
        return (None, None, None)

    instrument: Optional[str] = None
    if " sur " in raw:
        seg = raw.split(" sur ", 1)[1]
        instrument = (seg.split("!", 1)[0].strip().upper() + "!") if "!" in seg else seg.strip().upper()

    target_pos: Optional[int] = None
    needle = "La nouvelle position de la stratégie est"
    if needle in raw:
        try:
            right = raw.split(needle, 1)[1]
            num = (
                right.strip().split()[0]
                .replace("\u202f", "")
                .replace("\u00a0", "")
                .replace(",", ".")
            )
            target_pos = int(float(num))
        except Exception:
            target_pos = None

    raw_lower = raw.lower()
    hint: Optional[str] = None
    if "ordre sell" in raw_lower or " sell @" in raw_lower:
        hint = "SELL"
    elif "ordre buy" in raw_lower or " buy @" in raw_lower:
        hint = "BUY"

    return (instrument, target_pos, hint)
