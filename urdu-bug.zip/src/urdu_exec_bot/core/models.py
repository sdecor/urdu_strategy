from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass
class Signal:
    received_at: str
    minute_key: str
    second_key: str
    instrument: str
    target_pos: Optional[int]
    raw_action_hint: Optional[str]
