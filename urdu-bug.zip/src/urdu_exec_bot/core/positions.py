from __future__ import annotations
from typing import Any, Dict
import logging

from urdu_exec_bot.services.topstepx_client import TopstepXClient

log = logging.getLogger("urdu_exec_bot")

def _signed_net_from_row(row: Dict[str, Any]) -> int:
    try:
        t = int(row.get("type", 0))
        size = int(row.get("size", 0))
        if t == 1:
            return +abs(size)
        if t == 2:
            return -abs(size)
    except Exception:
        pass

    for k in ("netQuantity", "netQty", "net_qty", "net"):
        if k in row:
            try: return int(row[k])
            except Exception: pass

    b = row.get("buyQty") or row.get("longQty") or 0
    s = row.get("sellQty") or row.get("shortQty") or 0
    try:
        b_i = int(b); s_i = int(s)
        if b_i or s_i: return b_i - s_i
    except Exception:
        pass

    side = (row.get("side") or row.get("positionSide") or "").strip().lower()
    qty = row.get("qty") or row.get("quantity") or row.get("size") or 0
    try: q = int(qty)
    except Exception: q = 0
    if side in ("sell", "short", "ask"): return -abs(q)
    if side in ("buy", "long", "bid"):  return +abs(q)
    return 0

def positions_index(client: TopstepXClient, account_id: str) -> Dict[str, Any]:
    ok, data = client.position_search_open(account_id=account_id)
    log.debug("POS SEARCH OPEN ok=%s data=%s", ok, data)
    result = {"by_contract": {}, "by_symbol": {}, "ok": ok}
    if not ok or not isinstance(data, dict):
        return result

    rows = data.get("positions") or data.get("data") or data.get("items") or data.get("result") or []
    for r in rows:
        sym = (
            r.get("symbol") or r.get("instrument") or r.get("contractSymbol")
            or r.get("displaySymbol") or r.get("name") or ""
        )
        contract_id = (
            r.get("contractId") or r.get("contractID") or r.get("contract_id") or r.get("contract") or ""
        )
        sym_u = str(sym).upper()
        cid_u = str(contract_id).upper()
        net = _signed_net_from_row(r)
        if cid_u:
            result["by_contract"][cid_u] = net
        if sym_u:
            result["by_symbol"][sym_u] = net
    return result

def current_pos_from_index(index: Dict[str, Any], instrument: str, contract_id: str) -> int:
    cid_u = str(contract_id).upper()
    if cid_u and cid_u in index.get("by_contract", {}):
        return int(index["by_contract"][cid_u])
    ins = instrument.upper()
    if ins in index.get("by_symbol", {}):
        return int(index["by_symbol"][ins])
    k2 = ins.replace("!", "")
    if k2 in index.get("by_symbol", {}):
        return int(index["by_symbol"][k2])
    return 0
