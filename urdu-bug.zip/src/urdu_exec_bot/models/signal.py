from enum import Enum
from dataclasses import dataclass

class SignalAction(Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    FLAT = "FLAT"

@dataclass
class Signal:
    instrument: str
    action: SignalAction
    target_pos: int = 0

    @staticmethod
    def create(instrument: str, action: SignalAction) -> "Signal":
        target = {
            SignalAction.LONG: 1,
            SignalAction.SHORT: -1,
            SignalAction.FLAT: 0,
        }.get(action, 0)
        return Signal(instrument=instrument.upper(), action=action, target_pos=target)
