import json
import logging
import os
from pathlib import Path
from typing import List, Optional

from urdu_exec_bot.utils.settings_loader import load_settings, resolve_path
from urdu_exec_bot.state.store import StateStore

log = logging.getLogger("urdu_exec_bot")

class NdjsonWatcher:
    """
    Lit de nouvelles lignes NDJSON depuis un fichier avec offset persistant.
    """

    def __init__(
        self,
        json_path: str | Path,
        state_store: StateStore,
        *,
        offset_key: str = "ndjson",
        start_from_end: Optional[bool] = None,
        encoding: str = "utf-8",
    ) -> None:
        self.encoding = encoding
        self.settings = load_settings() or {}
        self.json_path: Path = resolve_path(json_path)
        self.state_store = state_store
        self.offset_key = offset_key
        self.start_from_end = (
            bool(start_from_end)
            if start_from_end is not None
            else bool(self.settings.get("ndjson_reader", {}).get("start_from_end", True))
        )

    def _get_saved_offset(self) -> int:
        try:
            return int(self.state_store.get_offset(self.offset_key))
        except Exception:
            return 0

    def _set_saved_offset(self, value: int) -> None:
        self.state_store.set_offset(self.offset_key, int(value))

    def read_new_lines(self) -> List[dict]:
        """
        Retourne les nouveaux objets JSON (1 par ligne) depuis le dernier offset.
        """
        p = self.json_path
        if not p.exists():
            return []

        try:
            size = os.path.getsize(p)
        except Exception:
            return []

        saved = self._get_saved_offset()

        if size < saved:
            new_off = size if self.start_from_end else 0
            self._set_saved_offset(new_off)
            log.debug("NDJSON truncated/rotated: reset offset to %s", new_off)
            saved = new_off

        if size == saved:
            return []

        objects: List[dict] = []

        try:
            with p.open("r", encoding=self.encoding, newline="") as f:
                f.seek(saved)
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            obj = json.loads(line)
                            objects.append(obj)
                        except json.JSONDecodeError as e:
                            log.warning("Invalid JSON line skipped: %s", e)
                f.seek(0, os.SEEK_END)
                new_off = f.tell()
        except Exception as e:
            log.warning("NdjsonWatcher read failed (%s): %s", p, e)
            return []

        if objects:
            self._set_saved_offset(new_off)
            log.debug("NDJSON read, offset %s -> %s", saved, new_off)

        return objects
