import pytest
import yaml
from urdu_exec_bot.parsers.signal_ndjson import SignalNdjsonParser
from urdu_exec_bot.models.signal import SignalAction

def test_ndjson_parser_mapping(settings_tmp):
    with open(settings_tmp["settings_path"], "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    parser = SignalNdjsonParser(settings=cfg)
    signal = parser.parse_entry({"raw": "ordre buy sur GC"})
    assert signal is not None
    assert signal.instrument == "GC"
    assert signal.action == SignalAction.LONG
