# fetch_contracts.py
import os
import json
import requests
from pathlib import Path

# --- Constantes d'API (chemins) ---
AUTH_LOGIN_KEY = "/api/Auth/loginKey"
CONTRACT_SEARCH = "/api/Contract/search"


# --------------------------
# Chargement simple du .env
# --------------------------
def _strip_inline_comment(v: str) -> str:
    in_single = False
    in_double = False
    out = []
    for ch in v:
        if ch == "'" and not in_double:
            in_single = not in_single
        elif ch == '"' and not in_single:
            in_double = not in_double
        if ch == "#" and not in_single and not in_double:
            break
        out.append(ch)
    return "".join(out).rstrip()


def load_env_file(dotenv_path: str = ".env") -> bool:
    p = Path(dotenv_path)
    if not p.exists():
        return False
    any_set = False
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = _strip_inline_comment(v).strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v
            any_set = True
    return any_set


def _mask(val: str | None, keep: int = 4) -> str:
    if not val:
        return ""
    if len(val) <= keep:
        return "*" * len(val)
    return "*" * (len(val) - keep) + val[-keep:]


def get_env_conf() -> dict:
    """Récupère la conf depuis les variables d'environnement (.env déjà chargé)."""
    return {
        "base_url": os.environ.get("TOPSTEPX_BASE_URL", "https://api.topstepx.com").rstrip("/"),
        "api_key": os.environ.get("TOPSTEPX_API_KEY", ""),
        "username": os.environ.get("TOPSTEPX_USERNAME", ""),
        "account_id": os.environ.get("TOPSTEPX_ACCOUNT_ID", ""),
    }


def print_env_params(conf: dict):
    print("=== PARAMÈTRES (.env) ===")
    print(f"BASE_URL   : {conf['base_url']}")
    print(f"USERNAME   : {conf['username']}")
    print(f"ACCOUNT_ID : {conf['account_id']}")
    print(f"API_KEY    : {_mask(conf['api_key'])}")
    print("=========================\n")


# --------------------------
# Auth & appels API
# --------------------------
def get_access_token_from_env(conf: dict, timeout: int = 15) -> str | None:
    """
    POST /api/Auth/loginKey
    body: {"userName": "<email>", "apiKey": "<clé>"}
    Retourne le token (str) ou None.
    """
    url = f"{conf['base_url']}{AUTH_LOGIN_KEY}"
    headers = {"Content-Type": "application/json"}
    body = {"userName": conf["username"], "apiKey": conf["api_key"]}
    try:
        r = requests.post(url, headers=headers, json=body, timeout=timeout)
        if r.status_code != 200:
            print(f"❌ Auth échouée ({r.status_code}) : {r.text}")
            return None
        data = r.json()
        token = data.get("token")
        if not token:
            print(f"❌ Auth: pas de 'token' dans la réponse : {data}")
            return None
        return token
    except Exception as e:
        print(f"⚠️ Erreur auth: {e}")
        return None


def fetch_contracts(jwt_token: str, symbol_search_text: str = "UB", live: bool = False, verbose: bool = True, conf: dict | None = None):
    """
    Récupère la liste des contrats (list[dict]) via POST /api/Contract/search.
    Utilise les entêtes x-username / x-account-id / x-api-key à partir du .env.
    """
    if conf is None:
        conf = get_env_conf()

    url = f"{conf['base_url']}{CONTRACT_SEARCH}"
    headers = {
        "accept": "application/json",
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/json",
        # Ajouts TopstepX utiles pour la gateway
        "x-api-key": conf["api_key"],
        "x-username": conf["username"],
        "x-account-id": str(conf["account_id"]),
    }
    data = {"live": bool(live), "searchText": str(symbol_search_text)}

    type_str = "LIVE" if live else "TOUS"
    contracts_list: list[dict] = []

    if verbose:
        print("\n" + "=" * 50)
        print(f"    RECHERCHE DES CONTRATS '{symbol_search_text}' ({type_str})")
        print("=" * 50)

    try:
        response = requests.post(url, headers=headers, json=data, timeout=15)
        if response.status_code == 200:
            payload = response.json()
            contracts_list = payload.get("contracts", [])
            if verbose:
                if contracts_list:
                    print(f"✅ {len(contracts_list)} contrat(s) trouvé(s) :\n")
                    for i, contract in enumerate(contracts_list, start=1):
                        contract_id = contract.get("id", "N/A")
                        contract_name = contract.get("name") or contract.get("symbol", "N/A")
                        contract_exchange = contract.get("exchange", "N/A")
                        contract_product_type = contract.get("productType", "N/A")
                        contract_term = contract.get("term", "N/A")
                        contract_currency = contract.get("currency", "N/A")
                        contract_tick_size = contract.get("tickSize", "N/A")
                        print(f"--- Contrat #{i} ---")
                        print(f"  🆔 ID              : {contract_id}")
                        print(f"  📛 Nom/Symbole     : {contract_name}")
                        print(f"  🏦 Exchange        : {contract_exchange}")
                        print(f"  📊 Type            : {contract_product_type}")
                        print(f"  📅 Échéance        : {contract_term}")
                        print(f"  💱 Devise          : {contract_currency}")
                        print(f"  📏 Tick Size       : {contract_tick_size}")
                        print("-" * 30)
                    print("\n📋 IDs des contrats trouvés :")
                    for c in contracts_list:
                        print(f"   - {c.get('id')}")
                else:
                    print("ℹ️  Aucun contrat trouvé pour cette recherche.")
        else:
            if verbose:
                print(f"❌ Échec de la recherche de contrats. Statut: {response.status_code}")
                print(f"   Réponse: {response.text}")
    except Exception as e:
        if verbose:
            print(f"⚠️ Erreur lors de la requête pour récupérer les contrats : {e}")

    return contracts_list


# --------------------------
# Script / CLI
# --------------------------
if __name__ == "__main__":
    import sys

    # 0) .env -> os.environ
    load_env_file(".env")
    conf = get_env_conf()
    print_env_params(conf)

    # 1) Token : argument #1 sinon auth via .env
    if len(sys.argv) >= 2 and sys.argv[1] and not sys.argv[1].startswith("-"):
        jwt_token = sys.argv[1]
        print("ℹ️ Utilisation du JWT passé en argument.")
        arg_shift = 1
    else:
        jwt_token = get_access_token_from_env(conf)
        if not jwt_token:
            jwt_token = input("Veuillez entrer un jeton JWT valide : ").strip()
        else:
            print("ℹ️ JWT obtenu via /api/Auth/loginKey.")
        arg_shift = 0

    if not jwt_token:
        print("❌ Impossible d'obtenir un jeton JWT.")
        sys.exit(1)

    # 2) Symbole à chercher : argument suivant sinon prompt (défaut UB)
    symbol_search_text = None
    if len(sys.argv) >= 2 + arg_shift:
        symbol_search_text = sys.argv[1 + arg_shift]
        print(f"ℹ️ Recherche du symbole (argument) : {symbol_search_text}")
    if not symbol_search_text:
        symbol_search_text = input("Symbole à rechercher (ex: UB, CBOT:UB1!, Ultra) [UB] : ").strip() or "UB"

    # 3) LIVE ? argument suivant sinon prompt (défaut False)
    live = False
    if len(sys.argv) >= 3 + arg_shift:
        live_arg = sys.argv[2 + arg_shift].lower()
        live = live_arg in ("1", "true", "yes", "y")
        print(f"ℹ️ Recherche des contrats LIVE = {live}")
    else:
        live_input = input("Rechercher seulement les contrats live ? (y/N) : ").strip().lower()
        live = live_input in ("y", "yes", "1")

    # 4) Appel
    contracts = fetch_contracts(jwt_token, symbol_search_text, live, verbose=True, conf=conf)

    # 5) Dump JSON brut
    print("\n=== LISTE DES CONTRATS (JSON brut) ===")
    print(json.dumps(contracts, indent=2, ensure_ascii=False))
