cd E:\sdecor\Development\URDU_bot
$env:PYTHONPATH = "E:\sdecor\Development\URDU_bot\src"
python -m urdu_exec_bot.app --debug-auth
