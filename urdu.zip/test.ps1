$ts = (Get-Date -Format "yyyy-MM-ddTHH:mm:00Z")



# Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre sell @ 1 effectué sur UB1!. La nouvelle position de la stratégie est -1"""
# Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre sell @ 1 effectué sur UB1!. La nouvelle position de la stratégie est 0""" 

# Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre buy @ 1 effectué sur UB1!. La nouvelle position de la stratégie est 0"""
# Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre buy @ 1 effectué sur UB1!. La nouvelle position de la stratégie est 1"""

Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre sell @ 1 effectué sur UB1!. La nouvelle position de la stratégie est 0"
Add-Content -Path "data\input\signals.csv" -Value "$ts,text/plain; charset=utf-8,""Urdu Blocks Indicator (7, 13, ALMA, 2, 5, 0,85, 0, BOTH, 14, 70, 30, 0, 0, 4 000): ordre sell @ 1 effectué sur UB1!. La nouvelle position de la stratégie est -1"""