from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from urdu_exec_bot.services.state_store import StateStore

log = logging.getLogger("urdu_exec_bot")


class CsvWatcher:
    """
    Lit uniquement les nouvelles lignes ajoutées depuis le dernier offset.
    À la première exécution (offset=0), on se place en fin de fichier (EOF) pour
    ignorer l'historique, puis on attend les lignes futures.
    """

    def __init__(self, *, csv_path: Path, state_store: StateStore) -> None:
        self._path = Path(csv_path)
        self._state = state_store
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._path.touch()

    def read_new_lines(self) -> List[str]:
        lines: List[str] = []
        size = self._path.stat().st_size
        offset = self._state.load_offset()

        # Première exécution: on saute l'historique et on se cale à EOF
        if offset == 0 and size > 0:
            self._state.save_offset(size)
            log.debug("CSV first run: fast-forward to EOF (offset=%s)", size)
            return lines  # rien à traiter maintenant

        # Lecture des ajouts depuis le dernier offset
        if size > offset:
            with self._path.open("r", encoding="utf-8", newline="") as f:
                f.seek(offset)
                chunk = f.read()
                self._state.save_offset(f.tell())
            # Normaliser séparateurs et éclater en lignes non vides
            for ln in chunk.splitlines():
                ln = ln.strip()
                if ln:
                    lines.append(ln)
            log.debug("CSV delta: read %d new line(s) (from %d to %d)", len(lines), offset, size)
        elif size < offset:
            # Fichier tronqué/rotaté: repartir de zéro mais sauter l’historique présent
            with self._path.open("r", encoding="utf-8", newline="") as f:
                f.seek(0, 2)  # EOF
                new_off = f.tell()
            self._state.save_offset(new_off)
            log.debug("CSV truncated/rotated: reset offset to EOF (%d)", new_off)

        return lines
