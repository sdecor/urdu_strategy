# src/urdu_exec_bot/core/constants.py
POLL_INTERVAL_SEC = 0.5
BETWEEN_ORDERS_SLEEP_SEC = 0.25
