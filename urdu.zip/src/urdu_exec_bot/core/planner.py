from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
import logging

from .signal import Signal

log = logging.getLogger("urdu_exec_bot")

def _coalesce_by_second(signals: List[Signal]) -> List[Tuple[str, str, str]]:
    """
    Renvoie une liste de tuples (action_code, instrument, second_key)
    Règles:
      - Si dans la même seconde on voit pos=0 + (BUY ou SELL) → plan = [CLOSE, OPEN_BUY/OPEN_SELL]
      - Si deux BUY → OPEN_BUY
      - Si deux SELL → OPEN_SELL
      - Si uniquement 0 → CLOSE
      - Si uniquement non-zéro → OPEN_BUY/OPEN_SELL selon le hint ou le signe
    """
    groups: Dict[Tuple[str, str], List[Signal]] = {}
    order_keys: List[Tuple[str, str]] = []
    for s in signals:
        key = (s.second_key, s.instrument)
        if key not in groups:
            groups[key] = []
            order_keys.append(key)
        groups[key].append(s)

    plan: List[Tuple[str, str, str]] = []

    for key in order_keys:
        sec_key, instrument = key
        lst = groups[key]

        # dédupe (target_pos, action_hint)
        dedup: List[Signal] = []
        seen = set()
        for x in lst:
            sig_key = (x.target_pos, x.raw_action_hint)
            if sig_key in seen:
                continue
            seen.add(sig_key)
            dedup.append(x)

        zeros = [x for x in dedup if x.target_pos == 0]
        nonzeros = [x for x in dedup if (x.target_pos is not None and x.target_pos != 0)]
        hints = {x.raw_action_hint for x in dedup if x.raw_action_hint}

        log.debug(
            "COALESCE SECOND %s %s zeros=%s nonzeros=%s hints=%s",
            instrument,
            sec_key,
            [z.target_pos for z in zeros],
            [n.target_pos for n in nonzeros],
            list(hints),
        )

        if zeros and nonzeros:
            plan.append(("CLOSE", instrument, sec_key))
            last_nz = nonzeros[-1]
            if last_nz.raw_action_hint == "BUY" or (last_nz.target_pos and last_nz.target_pos > 0):
                plan.append(("OPEN_BUY", instrument, sec_key))
            else:
                plan.append(("OPEN_SELL", instrument, sec_key))
            continue

        if zeros and not nonzeros:
            plan.append(("CLOSE", instrument, sec_key))
            continue

        if nonzeros and not zeros:
            if hints == {"BUY"}:
                plan.append(("OPEN_BUY", instrument, sec_key))
            elif hints == {"SELL"}:
                plan.append(("OPEN_SELL", instrument, sec_key))
            else:
                last_nz = nonzeros[-1]
                if last_nz.raw_action_hint == "BUY" or (last_nz.target_pos and last_nz.target_pos > 0):
                    plan.append(("OPEN_BUY", instrument, sec_key))
                else:
                    plan.append(("OPEN_SELL", instrument, sec_key))
            continue

    log.debug("COALESCE PLAN: %s", plan)
    return plan
