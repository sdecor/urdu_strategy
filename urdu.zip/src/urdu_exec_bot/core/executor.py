from __future__ import annotations

import logging
import time
import uuid
from typing import Dict, Iterable, Tuple

from urdu_exec_bot.services.state_store import StateStore
from urdu_exec_bot.services.topstepx_client import TopstepXClient, TSSide, TSOrderType

from .positions import positions_index, current_pos_from_index

log = logging.getLogger("urdu_exec_bot")

BETWEEN_ORDERS_SLEEP_SEC = 0.25

class Executor:
    def __init__(
        self,
        client: TopstepXClient,
        state_store: StateStore,
        account_id: str,
        contracts_map: Dict[str, str],
        lots_map: Dict[str, int],
        between_orders_sleep: float = BETWEEN_ORDERS_SLEEP_SEC,
    ) -> None:
        self.client = client
        self.state_store = state_store
        self.account_id = account_id
        self.contracts_map = {k.upper(): v for k, v in contracts_map.items()}
        self.lots_map = lots_map
        self.sleep_s = between_orders_sleep

    def _lot_for(self, instrument: str) -> int:
        return int(self.lots_map.get(instrument, self.lots_map.get("DEFAULT", 1)))

    def _contract_for(self, instrument: str) -> str:
        return self.contracts_map.get(instrument)

    def _refresh_idx(self):
        return positions_index(self.client, self.account_id)

    def _apply_and_refresh(self, instrument: str, contract_id: str):
        idx = self._refresh_idx()
        if idx.get("ok"):
            fresh = current_pos_from_index(idx, instrument, contract_id)
            self.state_store.set_position_abs(instrument, contract_id, fresh)
        return idx

    def process(self, second_plan: Iterable[Tuple[str, str, str]]) -> None:
        """
        second_plan: iterable de tuples (action_code, instrument, sec_key)
        """
        # snapshot initial (si dispo)
        idx = self._refresh_idx()
        api_pos_ok = bool(idx.get("ok", False))

        for action_code, instrument, sec_key in second_plan:
            contract_id = self._contract_for(instrument)
            if not contract_id:
                log.error("[%s] ? · ? ×? · contractId manquant (topstepx.contracts).", instrument)
                continue

            lot = self._lot_for(instrument)
            cur = current_pos_from_index(idx, instrument, contract_id) if api_pos_ok else self.state_store.get_position(instrument)

            log.debug(
                "WILL EXECUTE %s for %s @%s (cur=%s, lot=%s, contract=%s, api_pos_ok=%s)",
                action_code, instrument, sec_key, cur, lot, contract_id, api_pos_ok,
            )

            if action_code == "CLOSE":
                if cur == 0:
                    log.info("[%s] CLOSE ignoré (déjà FLAT).", instrument)
                    continue
                side = TSSide.BUY if cur < 0 else TSSide.SELL
                qty = abs(cur)
                ok, data = self.client.place_order(
                    contract_id=contract_id,
                    side=side,
                    order_type=TSOrderType.MARKET,
                    qty=qty,
                    custom_tag=f"urdu-{instrument.lower()}-{uuid.uuid4().hex[:8]}",
                )
                if ok:
                    order_id = data.get("orderId")
                    log.info(
                        "[%s] CLOSE · %s ×%s · account=%s · second=%s · orderId=%s",
                        instrument, "BUY" if side == TSSide.BUY else "SELL", qty, self.account_id, sec_key, order_id,
                    )
                    self.state_store.set_position_abs(instrument, contract_id, 0)
                    time.sleep(self.sleep_s)
                    idx = self._apply_and_refresh(instrument, contract_id)
                else:
                    log.error(
                        "[%s] CLOSE · %s ×%s · account=%s · second=%s · API_RESP=%s",
                        instrument, "BUY" if side == TSSide.BUY else "SELL", qty, self.account_id, sec_key, data,
                    )
                time.sleep(self.sleep_s)
                continue

            if action_code == "OPEN_BUY":
                side = TSSide.BUY
                qty = lot
                ok, data = self.client.place_order(
                    contract_id=contract_id,
                    side=side,
                    order_type=TSOrderType.MARKET,
                    qty=qty,
                    custom_tag=f"urdu-{instrument.lower()}-{uuid.uuid4().hex[:8]}",
                )
                if ok:
                    order_id = data.get("orderId")
                    log.info(
                        "[%s] OPEN-STEP · BUY ×%s · account=%s · second=%s · orderId=%s",
                        instrument, qty, self.account_id, sec_key, order_id,
                    )
                    self.state_store.apply_fill(instrument, contract_id, side, qty)
                    idx = self._apply_and_refresh(instrument, contract_id)
                else:
                    log.error(
                        "[%s] OPEN-STEP · BUY ×%s · account=%s · second=%s · API_RESP=%s",
                        instrument, qty, self.account_id, sec_key, data,
                    )
                continue

            if action_code == "OPEN_SELL":
                side = TSSide.SELL
                qty = lot
                ok, data = self.client.place_order(
                    contract_id=contract_id,
                    side=side,
                    order_type=TSOrderType.MARKET,
                    qty=qty,
                    custom_tag=f"urdu-{instrument.lower()}-{uuid.uuid4().hex[:8]}",
                )
                if ok:
                    order_id = data.get("orderId")
                    log.info(
                        "[%s] OPEN-STEP · SELL ×%s · account=%s · second=%s · orderId=%s",
                        instrument, qty, self.account_id, sec_key, order_id,
                    )
                    self.state_store.apply_fill(instrument, contract_id, side, qty)
                    idx = self._apply_and_refresh(instrument, contract_id)
                else:
                    log.error(
                        "[%s] OPEN-STEP · SELL ×%s · account=%s · second=%s · API_RESP=%s",
                        instrument, qty, self.account_id, sec_key, data,
                    )
                continue
