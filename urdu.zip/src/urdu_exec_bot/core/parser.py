from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from io import StringIO
from typing import Any, Dict, List, Optional, Tuple

from .models import Signal  # Signal(received_at, minute_key, second_key, instrument, target_pos, raw_action_hint)

log = logging.getLogger("urdu_exec_bot")


# ─────────────────────────── helpers: time keys ───────────────────────────
def _parse_iso_utc(ts: str) -> datetime:
    s = (ts or "").strip().replace(",", ".")
    try:
        if s.endswith("Z"):
            return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    except Exception:
        return datetime.now(timezone.utc)


def _minute_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:00Z")


def _second_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


# ─────────────────────────── helpers: CSV line ───────────────────────────
def parse_csv_line(line: str) -> Optional[Dict[str, Any]]:
    """
    Retourne un dict {received_at, content_type, raw} ou None si ligne d'entête/vides.
    """
    if not line or line.lower().startswith("received_at,"):
        return None
    reader = csv.reader(StringIO(line))
    try:
        row = next(reader, None)
    except Exception:
        return None
    if not row:
        return None
    return {
        "received_at": row[0] if len(row) > 0 else "",
        "content_type": row[1] if len(row) > 1 else "",
        "raw": row[2] if len(row) > 2 else "",
    }


# ─────────────────────────── helpers: extraction depuis raw ───────────────────────────
def _extract_from_kv(raw: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Supporte le format:
      "instrument:UB1!,position:0"
    Renvoie (instrument, target_pos) ou (None, None) si non applicable.
    """
    if not raw:
        return (None, None)

    txt = raw.strip().strip('"').strip()
    # fragmenter par virgule tout en restant simple (la valeur n'a pas de virgule)
    parts = [p.strip() for p in txt.split(",")]
    kv: Dict[str, str] = {}
    for p in parts:
        if ":" not in p:
            continue
        k, v = p.split(":", 1)
        kv[k.strip().lower()] = v.strip()

    ins = kv.get("instrument")
    pos = kv.get("position")

    instrument = ins.upper() if ins else None
    target_pos: Optional[int] = None
    if pos is not None:
        try:
            # nettoyer éventuels placeholders style {{strategy.position_size}}
            pp = pos.replace("{", "").replace("}", "")
            target_pos = int(float(pp))
        except Exception:
            target_pos = None

    return (instrument, target_pos)


def _extract_from_fr(raw: str) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    """
    Supporte l'ancien format FR:
      "La nouvelle position de la stratégie est -1 sur UB1! · ordre sell @ ..."
    Renvoie (instrument, target_pos, action_hint)
    """
    if not raw:
        return (None, None, None)

    # instrument après " sur "
    instrument: Optional[str] = None
    if " sur " in raw:
        seg = raw.split(" sur ", 1)[1]
        instrument = (seg.split("!", 1)[0].strip().upper() + "!") if "!" in seg else seg.strip().upper()

    # position après l’aiguille
    target_pos: Optional[int] = None
    needle = "La nouvelle position de la stratégie est"
    if needle in raw:
        try:
            right = raw.split(needle, 1)[1]
            num = (
                right.strip().split()[0]
                .replace("\u202f", "")
                .replace("\u00a0", "")
                .replace(",", ".")
            )
            target_pos = int(float(num))
        except Exception:
            target_pos = None

    raw_lower = raw.lower()
    action_hint: Optional[str] = None
    if "ordre sell" in raw_lower or " sell @" in raw_lower:
        action_hint = "SELL"
    elif "ordre buy" in raw_lower or " buy @" in raw_lower:
        action_hint = "BUY"

    return (instrument, target_pos, action_hint)


# ─────────────────────────── API publique ───────────────────────────
class SignalParser:
    """
    Transforme les lignes CSV en objets Signal.
    Gère deux formats de `raw`:
      1) "instrument:UB1!,position:0"  (NOUVEAU)
      2) "La nouvelle position de la stratégie est X sur UB1!" (+ éventuel "ordre buy/sell") (ANCIEN)
    """

    @staticmethod
    def parse_csv_line(line: str) -> Optional[Dict[str, Any]]:
        return parse_csv_line(line)

    @staticmethod
    def to_signal(rec: Dict[str, Any]) -> Optional[Signal]:
        raw = rec.get("raw", "") or ""

        # 1) essai du format KV
        instrument, target_pos = _extract_from_kv(raw)
        action_hint: Optional[str] = None

        # 2) si kv incomplet → fallback format FR
        if instrument is None or target_pos is None:
            ins_fr, pos_fr, hint_fr = _extract_from_fr(raw)
            instrument = instrument or ins_fr
            target_pos = target_pos if target_pos is not None else pos_fr
            action_hint = hint_fr

        if instrument is None or target_pos is None:
            return None

        ts = rec.get("received_at", "") or ""
        dt = _parse_iso_utc(ts)

        sig = Signal(
            received_at=ts,
            minute_key=_minute_key(dt),
            second_key=_second_key(dt),
            instrument=instrument,
            target_pos=target_pos,
            raw_action_hint=action_hint,  # peut rester None; le planner utilise le signe si pas d’hint
        )
        log.debug("PARSE SIGNAL: %s", sig)
        return sig
