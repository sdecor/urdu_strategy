from __future__ import annotations

import csv
from datetime import datetime, timezone
from io import StringIO
from typing import Any, Dict, Optional

def parse_csv_line(line: str) -> Optional[Dict[str, Any]]:
    if not line or line.lower().startswith("received_at,"):
        return None
    reader = csv.reader(StringIO(line))
    try:
        row = next(reader, None)
    except Exception:
        return None
    if not row:
        return None
    return {
        "received_at": row[0] if len(row) > 0 else "",
        "content_type": row[1] if len(row) > 1 else "",
        "raw": row[2] if len(row) > 2 else "",
    }

def parse_iso_utc(ts: str) -> datetime:
    s = (ts or "").strip().replace(",", ".")
    try:
        if s.endswith("Z"):
            return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    except Exception:
        return datetime.now(timezone.utc)

def minute_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:00Z")

def second_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
