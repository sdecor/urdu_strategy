from __future__ import annotations
from typing import Any, Dict
from urdu_exec_bot.utils.settings_loader import resolve_path
import logging

log = logging.getLogger("urdu_exec_bot")

def _get_default_lot(settings: Dict[str, Any]) -> int:
    strat = settings.get("strategy")
    if isinstance(strat, dict):
        try:
            return int(strat.get("default_lot", 1))
        except Exception:
            return 1
    if isinstance(strat, (int, str)):
        try:
            return int(strat)
        except Exception:
            return 1
    return 1

def _load_instruments_lots(settings: Dict[str, Any]) -> Dict[str, int]:
    lots: Dict[str, int] = {}
    cfg_files = (settings.get("config_files") or {})
    lots_file = cfg_files.get("lots") or cfg_files.get("instruments_lots")
    if lots_file:
        p = resolve_path(lots_file)
        if p.exists():
            import yaml
            try:
                data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            except Exception:
                data = {}
            if isinstance(data, dict):
                for k, v in data.items():
                    try:
                        lots[str(k).upper()] = int(v)
                    except Exception:
                        continue

    lots.setdefault("DEFAULT", _get_default_lot(settings))
    log.debug("LOTS MAP: %s", lots)
    return lots
