from __future__ import annotations

import io
import logging
import os
from pathlib import Path
from typing import List, Optional

from urdu_exec_bot.utils.settings_loader import load_settings, resolve_path
from urdu_exec_bot.state.store import StateStore

log = logging.getLogger("urdu_exec_bot")


class CsvWatcher:
    """
    Lit de nouvelles lignes d'un fichier CSV en utilisant un offset persistant.
    - Détecte la troncature/rotation du fichier (tail-like).
    - Respecte les options de settings.yaml: csv_reader.start_from_end, delimiter, has_header.
    - Stocke l'offset dans StateStore sous la clé 'csv' (par défaut).

    Interface:
      watcher = CsvWatcher(csv_path, state_store)
      new_lines = watcher.read_new_lines()  # -> List[str] (lignes CSV brutes)
    """

    def __init__(
        self,
        csv_path: str | Path,
        state_store: StateStore,
        *,
        offset_key: str = "csv",
        start_from_end: Optional[bool] = None,
        delimiter: Optional[str] = None,   # (actuellement non utilisé ici; parsing fait ailleurs)
        has_header: Optional[bool] = None,
        encoding: str = "utf-8",
    ) -> None:
        self.encoding = encoding
        self.settings = load_settings() or {}
        self.csv_cfg = (self.settings.get("csv_reader") or {})

        self.csv_path: Path = resolve_path(csv_path)
        self.state_store = state_store
        self.offset_key = offset_key

        # paramètres avec fallback sur settings.yaml
        self.start_from_end = (
            bool(start_from_end)
            if start_from_end is not None
            else bool(self.csv_cfg.get("start_from_end", True))
        )
        self.has_header = (
            bool(has_header)
            if has_header is not None
            else bool(self.csv_cfg.get("has_header", True))
        )
        # on laisse delimiter ici si besoin futur (parser fait ailleurs)
        self.delimiter = delimiter or self.csv_cfg.get("delimiter") or ","

        # mémorise le dernier inode/grosseur si besoin (Windows: on s'appuie surtout sur la taille)
        self._last_size: Optional[int] = None

    # ---------------------- helpers ----------------------
    def _get_saved_offset(self) -> int:
        try:
            return int(self.state_store.get_offset(self.offset_key))
        except Exception:
            return 0

    def _set_saved_offset(self, value: int) -> None:
        self.state_store.set_offset(self.offset_key, int(value))

    # ---------------------- public -----------------------
    def read_new_lines(self) -> List[str]:
        """
        Retourne toutes les nouvelles lignes depuis le dernier offset.
        Met à jour l’offset si des lignes sont lues.
        """
        p = self.csv_path
        if not p.exists():
            # fichier pas encore là
            return []

        try:
            size = os.path.getsize(p)
        except Exception:
            return []

        saved = self._get_saved_offset()

        # fichier tronqué / roulé ?
        if size < saved:
            # reset offset: EOF si start_from_end sinon 0
            new_off = size if self.start_from_end else 0
            self._set_saved_offset(new_off)
            log.debug("CSV truncated/rotated: reset offset to %s (%s)", "EOF" if self.start_from_end else 0, new_off)
            saved = new_off

        if size == saved:
            # rien de nouveau
            return []

        new_lines: List[str] = []
        start_offset = saved

        # lecture depuis l'offset
        try:
            with p.open("r", encoding=self.encoding, newline="") as f:
                f.seek(saved)
                # si on repart de 0 et qu'il y a un header, on le saute
                if self.has_header and saved == 0:
                    _ = f.readline()
                    saved = f.tell()

                # lire tout le reste
                chunk = f.read()
                # normaliser fin de lignes
                buf = io.StringIO(chunk)
                for ln in buf:
                    ln = ln.rstrip("\r\n")
                    if ln:
                        new_lines.append(ln)

                # nouvel offset = position en fin de lecture
                f.seek(0, os.SEEK_END)
                new_off = f.tell()
        except Exception as e:
            log.warning("CsvWatcher: lecture échouée (%s): %s", p, e)
            return []

        # mettre à jour l'offset seulement si on a lu
        if new_lines:
            self._set_saved_offset(new_off)
            # logging utile pour debug
            if start_offset == 0 and self.has_header:
                log.debug("CSV start (header skipped), offset %s -> %s (+%d bytes)", start_offset, new_off, new_off - start_offset)
            else:
                log.debug("CSV read, offset %s -> %s (+%d bytes)", start_offset, new_off, new_off - start_offset)

        return new_lines
