# Couche de compatibilité pour l'ancien import:
#   from urdu_exec_bot.csv_watcher import CsvWatcher
from urdu_exec_bot.csv.watcher import CsvWatcher  # noqa: F401
