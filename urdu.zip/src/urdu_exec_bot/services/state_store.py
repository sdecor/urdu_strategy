from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


class StateStore:
    """
    Fichier JSON simple qui conserve :
      - csv_offset (pointeur de lecture du CSV)
      - positions locales (par instrument) pour fallback/sync rapide
        {
          "csv_offset": 1234,
          "positions": {
            "UB1!": {"contractId": "CON.F.US.ULA.U25", "net": -1},
            "GC1!": {"contractId": "CON.F.US.GCE.Z25", "net": 0}
          }
        }
    """

    def __init__(self, path: Optional[str] = None) -> None:
        self._path = Path(path or "data/state.json")
        self._data: Dict[str, Any] = {
            "csv_offset": 0,
            "positions": {}
        }
        self._loaded = False

    # ---------------- Base I/O ----------------

    def load(self) -> Dict[str, Any]:
        if self._path.exists():
            try:
                raw = self._path.read_text(encoding="utf-8") or ""
                if raw.strip():
                    self._data = json.loads(raw)
            except Exception:
                # fichier corrompu → garder les valeurs par défaut
                pass
        self._loaded = True
        return self._data

    def save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    # ---------------- CSV offset ----------------

    def load_offset(self) -> int:
        try:
            return int(self._data.get("csv_offset", 0))
        except Exception:
            return 0

    def save_offset(self, offset: int) -> None:
        self._data["csv_offset"] = int(offset)
        self.save()

    # ---------------- Positions (cache local) ----------------

    def get_position(self, instrument: str) -> int:
        inst = (instrument or "").upper()
        pos = (self._data.get("positions") or {}).get(inst) or {}
        try:
            return int(pos.get("net", 0))
        except Exception:
            return 0

    def get_contract_id(self, instrument: str) -> str:
        inst = (instrument or "").upper()
        pos = (self._data.get("positions") or {}).get(inst) or {}
        return str(pos.get("contractId", "") or "")

    def set_position_abs(self, instrument: str, contract_id: str, net: int) -> None:
        inst = (instrument or "").upper()
        self._data.setdefault("positions", {})
        self._data["positions"][inst] = {
            "contractId": str(contract_id or ""),
            "net": int(net)
        }
        self.save()

    def apply_fill(self, instrument: str, contract_id: str, side: int, qty: int) -> None:
        """
        Met à jour le cache local après un ordre accepté.
        - BUY (side=0)  => net += qty
        - SELL (side=1) => net -= qty
        """
        inst = (instrument or "").upper()
        cur_net = self.get_position(inst)
        try:
            q = int(qty)
        except Exception:
            q = 0

        if int(side) == 0:      # BUY
            cur_net += q
        else:                    # SELL
            cur_net -= q

        self.set_position_abs(inst, contract_id, cur_net)
