# src/urdu_exec_bot/app.py
from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from typing import List

from dotenv import load_dotenv

load_dotenv()  # charge .env dès le démarrage

# ───────── LOGGING ─────────
LOG_FILE = "logs/urdu_exec_bot.log"
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_FILE, encoding="utf-8", mode="a"),
    ],
    force=True,
)
logging.getLogger("urllib3").setLevel(logging.DEBUG)
logging.getLogger("requests").setLevel(logging.DEBUG)
log = logging.getLogger("urdu_exec_bot")

# ───────── IMPORTS PROJET ─────────
from urdu_exec_bot.utils.settings_loader import load_settings, resolve_path
from urdu_exec_bot.csv_watcher import CsvWatcher
from urdu_exec_bot.services.state_store import StateStore
from urdu_exec_bot.services.topstepx_client import TopstepXClient
from urdu_exec_bot.app_support import _load_instruments_lots

# cœur métier désormais externalisé
from urdu_exec_bot.core.signal import Signal  # dataclass
from urdu_exec_bot.core.parser import parse_csv_line as _parse_csv_line, to_signal as _to_signal
from urdu_exec_bot.core.planner import _coalesce_by_second
from urdu_exec_bot.core.executor import Executor

POLL_INTERVAL_SEC = 0.5


def run() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug-auth", action="store_true", help="Verbose auth/requests logging")
    parser.add_argument("--debug-io", action="store_true", help="Verbose IO parsing")
    args, _ = parser.parse_known_args()

    settings = load_settings() or {}
    paths = settings.get("paths") or {}
    csv_input = paths.get("csv_input") or "data/input/signals.csv"
    csv_path = resolve_path(csv_input)

    state_store = StateStore()
    _ = state_store.load()

    client = TopstepXClient()
    top_cfg = settings.get("topstepx") or {}
    contracts_map = {str(k).upper(): str(v) for k, v in (top_cfg.get("contracts") or {}).items()}
    lots_map = _load_instruments_lots(settings)
    account_id = os.getenv("TOPSTEPX_ACCOUNT_ID") or str(top_cfg.get("account_id", "")) or ""

    watcher = CsvWatcher(csv_path=csv_path, state_store=state_store)
    executor = Executor(
        client=client,
        state_store=state_store,
        account_id=account_id,
        contracts_map=contracts_map,
        lots_map=lots_map,
    )

    log.info("URDU Exec Bot en marche · account_id=%s · CSV=%s", account_id, csv_path)
    log.debug("SETTINGS: %s", settings)
    log.debug("CONTRACTS MAP: %s", contracts_map)

    while True:
        try:
            raw_lines = watcher.read_new_lines()
            if raw_lines:
                if args.debug_io:
                    log.debug("RAW LINES (%d): %s", len(raw_lines), raw_lines)

                signals: List[Signal] = []
                for ln in raw_lines:
                    rec = _parse_csv_line(ln)
                    if not rec:
                        continue
                    sig = _to_signal(rec)
                    if sig and sig.target_pos is not None:
                        signals.append(sig)
                if not signals:
                    time.sleep(POLL_INTERVAL_SEC)
                    continue

                second_plan = _coalesce_by_second(signals)  # [(action_code, instrument, sec_key), ...]
                executor.process(second_plan)

        except Exception as e:
            log.exception("loop error: %s", e)

        time.sleep(POLL_INTERVAL_SEC)


def main() -> int:
    return run()


if __name__ == "__main__":
    sys.exit(main())
