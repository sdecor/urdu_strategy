from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Tuple

from urdu_exec_bot.utils.settings_loader import load_settings  # on réutilise ton loader

from .auth import TopstepXAuth
from .http import TopstepXHttp
from .models import ApiResponse, OrderRequest, TSOrderType, TSSide

log = logging.getLogger("urdu_exec_bot")


DEFAULT_ENDPOINTS = {
    "login_key": "/api/Auth/loginKey",
    "validate_token": "/api/Auth/validate",
    "order_search": "/api/Order/search",
    "order_search_open": "/api/Order/searchOpen",
    "order_cancel": "/api/Order/cancel",
    "position_search_open": "/api/Position/searchOpen",
    "contract_available": "/api/Contract/available",
    "contract_search": "/api/Contract/search",
    "contract_search_by_id": "/api/Contract/searchById",
    "order_place": "/api/Order/place",
    "account_search": "/api/Account/search",
}


class TopstepXClient:
    """
    Client “haut niveau” : s’occupe de l’auth et expose des méthodes simples.
    API de retour compatible avec ton app: (ok: bool, data: Any)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        username: Optional[str] = None,
        account_id: Optional[str] = None,
        auth_style: Optional[str] = None,
        endpoints: Optional[Dict[str, str]] = None,
        timeout: float = 15.0,
    ) -> None:
        # 1) charge settings.yaml si dispo
        settings = load_settings() or {}
        ts_cfg = (settings.get("topstepx") or {})
        ep_cfg = (ts_cfg.get("endpoints") or {})

        # 2) récupère .env > sinon settings > sinon défaut
        base_url = base_url or os.getenv("TOPSTEPX_BASE_URL") or ts_cfg.get("base_url") or "https://api.topstepx.com"
        api_key = api_key or os.getenv("TOPSTEPX_API_KEY") or ""
        username = username or os.getenv("TOPSTEPX_USERNAME") or ts_cfg.get("username") or ""
        account_id = account_id or os.getenv("TOPSTEPX_ACCOUNT_ID") or str(ts_cfg.get("account_id") or "")
        auth_style = (auth_style or os.getenv("TOPSTEPX_AUTH_STYLE") or ts_cfg.get("auth", {}).get("style") or "both")

        self.endpoints = {**DEFAULT_ENDPOINTS, **ep_cfg, **(endpoints or {})}

        # Sanity check minimal (on log seulement, pas d’exception dure)
        if not api_key or not username or not account_id:
            log.error("TOPSTEPX_API_KEY/TOPSTEPX_USERNAME/TOPSTEPX_ACCOUNT_ID sont obligatoires.")

        self.http = TopstepXHttp(
            base_url=base_url,
            api_key=api_key,
            username=username,
            account_id=str(account_id),
            auth_style=auth_style,
            timeout=timeout,
        )

        # Auth initiale (lazy: on tentera la connexion à la 1ère requête si pas de token)
        self._ensure_token()

    # ─────────────────────────── Helpers ───────────────────────────
    def _ensure_token(self) -> None:
        if not self.http.token:
            ok, token = TopstepXAuth.login_key(self.http)
            if ok and token:
                self.http.token = token

    def _resp(self, status: int, data: Any) -> ApiResponse:
        ok = (200 <= status < 300)
        return ApiResponse(ok=ok, data=data)

    # ─────────────────────────── API Publique ───────────────────────────
    def position_search_open(self, account_id: Optional[str] = None) -> Tuple[bool, Any]:
        """
        POST /api/Position/searchOpen {accountId}
        Retourne (ok, data)
        """
        self._ensure_token()
        acct = str(account_id or self.http.account_id)
        status, data = self.http.post(self.endpoints["position_search_open"], {"accountId": int(acct)})
        return self._resp(status, data).as_tuple()

    def place_order(
        self,
        *,
        contract_id: str,
        side: TSSide,
        order_type: TSOrderType,
        qty: int,
        custom_tag: Optional[str] = None,
        account_id: Optional[str] = None,
    ) -> Tuple[bool, Any]:
        """
        POST /api/Order/place
        body: { accountId, contractId, side, size, type, customTag? }
        """
        self._ensure_token()
        acct = int(account_id or int(self.http.account_id))
        req = OrderRequest(
            account_id=acct,
            contract_id=contract_id,
            side=side,
            order_type=order_type,
            qty=qty,
            custom_tag=custom_tag,
        )
        status, data = self.http.post(self.endpoints["order_place"], req.to_payload())
        return self._resp(status, data).as_tuple()

    # (facultatif) quelques helpers utiles si tu veux plus tard
    def get_open_orders(self, account_id: Optional[str] = None) -> Tuple[bool, Any]:
        self._ensure_token()
        acct = int(account_id or int(self.http.account_id))
        status, data = self.http.post(self.endpoints["order_search_open"], {"accountId": acct})
        return self._resp(status, data).as_tuple()

    def cancel_order(self, order_id: int, account_id: Optional[str] = None) -> Tuple[bool, Any]:
        self._ensure_token()
        acct = int(account_id or int(self.http.account_id))
        status, data = self.http.post(self.endpoints["order_cancel"], {"accountId": acct, "orderId": int(order_id)})
        return self._resp(status, data).as_tuple()
