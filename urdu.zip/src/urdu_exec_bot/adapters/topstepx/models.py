from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Dict, Optional


class TSSide(IntEnum):
    # ⚠️ Numéros d’après tes logs: BUY=0, SELL=1
    BUY = 0
    SELL = 1


class TSOrderType(IntEnum):
    # ⚠️ D’après tes logs: MARKET=2
    MARKET = 2
    # (si besoin plus tard) LIMIT=0, STOP=1, etc.


@dataclass
class OrderRequest:
    account_id: int
    contract_id: str
    side: TSSide
    qty: int
    order_type: TSOrderType = TSOrderType.MARKET
    custom_tag: Optional[str] = None

    def to_payload(self) -> Dict[str, Any]:
        payload = {
            "accountId": self.account_id,
            "contractId": self.contract_id,
            "side": int(self.side),
            "size": int(self.qty),
            "type": int(self.order_type),
        }
        if self.custom_tag:
            payload["customTag"] = self.custom_tag
        return payload


@dataclass
class ApiResponse:
    ok: bool
    data: Any

    def as_tuple(self):
        return self.ok, self.data
