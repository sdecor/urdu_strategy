oui. maintenant qu’on a sorti le “cœur” d’`app.py`, voici ce qui vaut la peine de modulariser tout de suite, classé par priorité, avec des découpes concrètes (noms de fichiers/chemins prêts à créer).

# Priorité A (gros morceaux, gain immédiat)

- **TopstepX client** (actuel: `src/urdu_exec_bot/services/topstepx_client.py`)

  - Découper en “adapter” propre :

    - `src/urdu_exec_bot/adapters/topstepx/auth.py` (loginKey, cache/refresh du token)
    - `src/urdu_exec_bot/adapters/topstepx/http.py` (Session, base_url, headers communs, retries/backoff)
    - `src/urdu_exec_bot/adapters/topstepx/models.py` (dataclasses: `OrderRequest`, `OrderResponse`, `PositionRow`…)
    - `src/urdu_exec_bot/adapters/topstepx/client.py` (API publique: `place_order`, `position_search_open`, etc., en s’appuyant sur `http.py` + `models.py`)

  - Bénéfice: code testable, erreurs centralisées, logs cohérents, facilité d’évolution.

- **State store** (actuel: `src/urdu_exec_bot/services/state_store.py`)

  - Séparer la persistance et le modèle :

    - `src/urdu_exec_bot/state/models.py` (ex: `PositionSnapshot`, `TradeState`)
    - `src/urdu_exec_bot/state/store.py` (API in-memory: get/set/apply_fill)
    - `src/urdu_exec_bot/state/repository_file.py` (implémentation fichier JSON)

  - Bénéfice: tests unitaires faciles (mock repo), pas d’E/S dans la logique.

- **CSV watcher** (actuel: `src/urdu_exec_bot/csv_watcher.py`)

  - Extraire la gestion d’offsets/rotations :

    - `src/urdu_exec_bot/io/csv_watcher.py` (tail + lecture)
    - `src/urdu_exec_bot/io/offsets.py` (lecture/écriture offset)
    - `src/urdu_exec_bot/io/rotation.py` (détection de rotation/troncature)

  - Bénéfice: robustesse sur fichiers tournants, responsabilité unique.

# Priorité B (structure & robustesse)

- **Chargement de config** (actuel: `src/urdu_exec_bot/utils/settings_loader.py`)

  - Vers modèles typés + fusion YAML + `.env` :

    - `src/urdu_exec_bot/config/models.py` (Pydantic ou dataclasses: `AppSettings`, `TopstepXSettings`, etc.)
    - `src/urdu_exec_bot/config/loader.py` (merge .env/YAML, validation, valeurs par défaut)
    - `src/urdu_exec_bot/config/paths.py` (résolution chemins)

  - Bénéfice: erreurs de config détectées tôt, IDE autocomplétion.

- **Journalisation**

  - `src/urdu_exec_bot/logging_setup.py` (charge `config/logging.yaml` si présent, sinon fallback basicConfig)
  - Bénéfice: logs homogènes, facile à régler sans toucher le code.

- **Risque / Brackets** (si déjà prévu par `risk.yaml`)

  - `src/urdu_exec_bot/risk/manager.py` (lecture `risk.yaml`, calcul SL/TP, préparation des ordres enfants)
  - Bénéfice: séparer le “quoi” (stratégie) du “comment” (exécution & gestion du risque).

# Priorité C (qualité de vie & tests)

- **Exceptions & erreurs**

  - `src/urdu_exec_bot/core/exceptions.py` (ex: `PositionUnavailable`, `ApiError`, `ConfigError`…)
  - Bénéfice: messages clairs, gestion fine dans l’exécuteur.

- **Contrats d’interface (inversion de dépendances)**

  - `src/urdu_exec_bot/ports/execution.py` (interface `OrderExecutor`)
  - `src/urdu_exec_bot/ports/positions.py` (interface `PositionProvider`)
  - L’impl TopstepX devient une **implémentation d’adapter**, test unitaire du core sans API réelle.

- **Utilitaires communs**

  - `src/urdu_exec_bot/utils/time.py` (clock injectable pour tests)
  - `src/urdu_exec_bot/utils/uuid.py` (génération tags/IDs centralisée)
  - Bénéfice: tests déterministes.

---

## Impact minimal côté `app.py`

`app.py` reste très fin : il orchestre (charge settings, crée `CsvWatcher`, passe par `core.parser` → `core.planner` → `core.executor`).
En modularisant les blocs ci-dessus, on améliore la **testabilité**, la **lisibilité**, et on limite les régressions (chaque pièce a son périmètre).

Si tu veux, je te fournis les squelettes (fichiers vides + signatures) pour l’un des paquets A (par ex. l’adapter TopstepX) afin que tu puisses migrer progressivement sans casse.
